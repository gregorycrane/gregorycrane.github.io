Canvas import package: 20 multiple-choice questions from Aeschylus, Eumenides, Smyth translation. Each answer identifies both speaker and dramatic phase.
